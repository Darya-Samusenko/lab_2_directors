import React, {Component} from "react";

import {Button, Container, Form, FormControl, Nav, Navbar} from 'react-bootstrap'
import {BrowserRouter as Router, Routes, Route, Link} from "react-router-dom";

import Home from "../pages/Home";
import Writers from "../pages/Writers";
import Kupala from "../pages/Kupala"
import Kolas from "../pages/Kolas"
import Tank from "../pages/Tank"
import Korot from "../pages/Korotkevich"
import Bagdanovich from "../pages/Bagdanovich"
import Melez from "../pages/Melez"


export default class Header extends Component{
    render() {
        return(
            <>
                <Navbar bg="light" expand="lg">
                    <Container fluid>
                        <Navbar.Brand href="#">Wiki</Navbar.Brand>
                        <Navbar.Toggle aria-controls="navbarScroll" />
                        <Navbar.Collapse id="navbarScroll">
                            <Nav
                                className="me-auto my-2 my-lg-0"
                                style={{ maxHeight: '100px' }}
                                navbarScroll
                            >
                                <Nav.Link href="/">Home</Nav.Link>
                                <Nav.Link href="/writers">Writers</Nav.Link>

                            </Nav>
                            <Form className="d-flex">
                                <Form.Control
                                    type="search"
                                    placeholder="Search"
                                    className="me-1"
                                    aria-label="Search"
                                />
                                <Button variant="outline-success">Search</Button>
                            </Form>
                        </Navbar.Collapse>
                    </Container>
                </Navbar>
            <Router>
                <Routes>
                    <Route exact path="/" element={<Home/>}/>
                    <Route exact path="/writers" element={<Writers/>}/>
                    <Route exact path = '/Kupala' element = {<Kupala/>}/>
                    <Route exact path = '/Kolas' element = {<Kolas/>}/>
                    <Route exact path = '/Tank' element = {<Tank/>}/>
                    <Route exact path = '/Korotkevich' element = {<Korot/>}/>
                    <Route exact path = '/Bagdanovich' element = {<Bagdanovich/>}/>
                    <Route exact path = '/Melez' element = {<Melez/>}/>
                </Routes>
            </Router>
            </>
        )
    }
}