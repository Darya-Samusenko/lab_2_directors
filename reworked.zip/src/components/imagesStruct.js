import kupala1 from "../accerts/kupalaGallery/1.jpg"
import kupala2 from "../accerts/kupalaGallery/2.jpg"
import kupala3 from "../accerts/kupalaGallery/3.jpg"
import kupala4 from "../accerts/kupalaGallery/4.jpg"
import kupala5 from "../accerts/kupalaGallery/5.jpg"

import kolas1 from "../accerts/kolasGallery/1.jpg"
import kolas2 from "../accerts/kolasGallery/2.jpg"
import kolas3 from "../accerts/kolasGallery/3.jpg"
import kolas4 from "../accerts/kolasGallery/4.jpg"
import kolas5 from "../accerts/kolasGallery/5.jpg"

import tank1 from "../accerts/tankGallery/1.jpg"
import tank2 from "../accerts/tankGallery/2.jpg"
import tank3 from "../accerts/tankGallery/3.jpg"
import tank4 from "../accerts/tankGallery/4.jpg"
import tank5 from "../accerts/tankGallery/5.jpg"

import korot1 from "../accerts/korotkevichGallery/1.jpg"
import korot2 from "../accerts/korotkevichGallery/2.jpg"
import korot3 from "../accerts/korotkevichGallery/3.jpg"
import korot4 from "../accerts/korotkevichGallery/4.jpg"
import korot5 from "../accerts/korotkevichGallery/5.jpg"

import bagdanovich1 from "../accerts/bagdanovichGallery/1.jpg"
import bagdanovich2 from "../accerts/bagdanovichGallery/2.jpg"
import bagdanovich3 from "../accerts/bagdanovichGallery/3.jpg"
import bagdanovich4 from "../accerts/bagdanovichGallery/4.jpg"
import bagdanovich5 from "../accerts/bagdanovichGallery/5.jpg"

import melez1 from "../accerts/melezGallery/1.jpg"
import melez2 from "../accerts/melezGallery/2.jpg"
import melez3 from "../accerts/melezGallery/3.jpg"
import melez4 from "../accerts/melezGallery/4.jpg"
import melez5 from "../accerts/melezGallery/5.jpg"

const writersImages = {
    kupala: [kupala1, kupala2, kupala3, kupala4, kupala5],
    kolas: [kolas1, kolas2, kolas3, kolas4, kolas5],
    tank: [tank1, tank2, tank3 , tank4, tank5],
    korotkevich: [korot1, korot2, korot3, korot4, korot5],
    bagdanovich: [bagdanovich1, bagdanovich2, bagdanovich3, bagdanovich4, bagdanovich5],
    melez: [melez1, melez2, melez3, melez4, melez5]
};

export default writersImages;